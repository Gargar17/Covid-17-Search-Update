# covid-19-tracker

     This is a web app in which 
      You can use to get track of corona cases 
      all over the world 
.
![Screenshot_20200515-034452](https://user-images.githubusercontent.com/54102389/82007649-a789aa80-9662-11ea-95ca-60b2640dc764.png)
  when page is fully loaded 
![Screenshot_20200515-034510](https://user-images.githubusercontent.com/54102389/82007695-c5efa600-9662-11ea-9063-8f0a4b820655.png)
  Results for search
![Screenshot_20200515-034528](https://user-images.githubusercontent.com/54102389/82007734-ddc72a00-9662-11ea-871b-6434fb9f9ebe.png)
  Error screen



The app stores every country you search to localStorage 
  then print it out as your recent sesrch 
